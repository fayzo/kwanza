var rw = {
    "welcome": "murakaze neza",
    "afternoon": "Good afternoom",
    "pets": [{
        "animal": "dog",
        "name": "Fido"
    },
    {
        "animal": "cat",
        "name": "Felix"
    },
    {
        "animal": "hamster",
        "name": "Lightning"
    }
    ]
};