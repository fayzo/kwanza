<?php 
session_start();
include('../init.php');
$users->preventUsersAccess($_SERVER['REQUEST_METHOD'],realpath(__FILE__),realpath($_SERVER['SCRIPT_FILENAME']));

if (isset($_POST['movies_id']) && !empty($_POST['movies_id'])) {
    $user_id= $_SESSION['key'];
    $movies_id = $_POST['movies_id'];
     ?>
     
<div class="movies-popup">
    
    <div class="wrap6" id="disabler">
        <div class="wrap6Pophide" onclick="togglePopup ( )" ></div>
        <span class="colose">
        	<button class="close-imagePopup"><i class="fa fa-times" aria-hidden="true"></i></button>
        </span>
        <div class="img-popup-wrap" id="popupEnd">
            <div class="img-popup-body">
                <button class="btn btn-success btn-sm"  onclick="togglePopup ( )">close</button>

             <?php echo $movies->moviesWatchVideo($movies_id) ?>

           </div><!-- img-popup-body -->
        </div><!-- user-show-popup-box -->
    <!-- </div> Wrp4 -->
</div> <!-- apply-popup" -->

<?php } 