<?php
	$lang = array(
		"title" => "iyi ni website yawe",
		"home" => "Murugo",
		"pages" => "Urupapuro",
		"posts" => "Postiga",
		"about" => "Ibisobanuro",
		"description" => "description",
		"lang_en" => "Engleski",
		"lang_bs" => "Bosanski"
	);
?>