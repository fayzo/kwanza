<?php
	$lang = array(
		"title" => "ton website",
		"home" => "Home",
		"pages" => "Page",
		"posts" => "Post",
		"about" => "About",
		"description" => "description",
		"lang_en" => "Engleski",
		"lang_bs" => "Bosanski"
	);
?>