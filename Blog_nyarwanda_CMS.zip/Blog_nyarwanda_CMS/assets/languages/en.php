<?php
	$lang = array(
		"title" => "My Amazing Website",
		"home" => "Home",
		"pages" => "Page",
		"posts" => "Posts",
		"about" => "About",
		"description" => "description",
		"description" => "This is explanation about my amazing website!",
		"lang_en" => "English",
		"lang_bs" => "Bosnian"
	);
?>