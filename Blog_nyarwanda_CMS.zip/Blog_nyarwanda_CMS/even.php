<?php 
for ($i=2; $i < 10; $i+=3) { 
    echo $i;
}
?>